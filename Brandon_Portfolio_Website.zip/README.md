
# Brandon Moore-Trye – Theatre Technician Portfolio

This is a personal portfolio site built using HTML, CSS, and JavaScript.
It showcases Brandon's experience in lighting, sound, and live production.

## How to Launch

1. Upload all files to a public GitHub repository.
2. Go to the repository's Settings > Pages.
3. Select 'main' branch and '/root' folder.
4. Click Save.
5. Visit your new site at `https://yourusername.github.io/repositoryname`.

Built with ❤️ for theatre tech.
