
const root = document.getElementById("root");
root.innerHTML = `
  <div>
    <h1>Brandon Moore-Trye</h1>
    <p>Theatre Technician | Lighting & Sound Specialist | Live Production Student</p>
    <p>Melbourne, VIC | 0459 390 662 | brandonmooretrye@gmail.com</p>

    <h2>Professional Profile</h2>
    <p>
      I am a dedicated and versatile theatre technician with over three years of hands-on experience in lighting and sound for live performances.
      Currently completing a Diploma of Live Production and Technical Services at Melbourne Polytechnic, I bring a deep passion for production design,
      precise technical execution, and a team-first attitude to every show.
    </p>

    <h2>Technical Skills</h2>
    <ul>
      <li>Lighting: ETC Ion, MA onPC, dome ops (24+ shows)</li>
      <li>Sound: Behringer X32, Yamaha LS9, QLab</li>
      <li>Stagecraft: rigging, fly systems, set builds, backstage crew</li>
      <li>Software: QLab, Vectorworks (basic), projection</li>
      <li>WHS: manual handling, cable management, PPE, risk assessment</li>
    </ul>

    <h2>Education</h2>
    <p><strong>Diploma of Live Production and Technical Services</strong><br>Melbourne Polytechnic, Prahran – Expected Dec 2025</p>
    <p><strong>High School Diploma</strong><br>Graduated Nov 2020</p>

    <h2>Industry Experience</h2>
    <ul>
      <li><strong>Mystic Entertainmentz</strong> – Lighting & Sound Technician (Mar 2022–Present)</li>
      <li><strong>Kryal Castle</strong> – Performer & Stage Support (Sept 2022–Jan 2025)</li>
      <li><strong>City Oval Hotel</strong> – Events Support (Jun 2020–Sept 2022)</li>
    </ul>

    <h2>Highlight Gigs & Projects</h2>
    <ul>
      <li>BCMA Gigs – Lighting operation with creative flair</li>
      <li>Mystic Dome Series – Cue management and scene lighting</li>
      <li>Polytechnic Theatre – Lighting & backstage crew roles</li>
      <li>Festival Rigs – Temporary lighting setup under pressure</li>
    </ul>

    <h2>Additional Skills</h2>
    <ul>
      <li>Plays 10 instruments (strong cue timing)</li>
      <li>Can ski (valuable for winter gigs)</li>
      <li>3 years of volunteer work helping kids and the homeless</li>
      <li>Calm under pressure, strong communicator</li>
    </ul>

    <h2>References</h2>
    <ul>
      <li>Matthew Heenan – Head of Mystic Entertainmentz – 0408 588 668</li>
      <li>Laurence Heenan – Lighting Co-Lead, Mystic – 0437 420 860</li>
    </ul>
  </div>
`;
